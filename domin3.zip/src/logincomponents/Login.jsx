import React from 'react';
import './Login.css'

const LoginPage = () => {
    return (
        <div>
   <div className="sc-dnqmqq diTRFe">
      <div className="overlay"></div>
      <div className="">
         <span></span>
         <div className="injectStyles-sc-1jy9bcf-0 gexXsN"></div>
      </div>
      <div className="side-nav" style={{width: "32%", transition: "all 1s ease 0s", top: "3.1rem", right: "0px"}}>
         <div className="ovrly-child">
            <div>
               <div className="sc-bYSBpT fQlqsy">
                  <img className="bkgrnd__img" src="https://pizzaonline.dominos.co.in/static/assets/login_pizza_image.png" srcSet="https://pizzaonline.dominos.co.in/static/assets/login_pizza_image.png 1x, https://pizzaonline.dominos.co.in/static/assets/login_pizza_image@2x.png 2x, https://pizzaonline.dominos.co.in/static/assets/login_pizza_image@3x.png 3x" alt=''/>
                  <img className="lg__img" src="https://pizzaonline.dominos.co.in/static/assets/Dominos_logo.svg" alt=''/>
                  <div className="hd-img">
                     <div className="hd-img__txt">
                     <span>Login</span> to unlock awesome new features</div>
                     <div className="hd-img__sbtxt">
                        <div>
                           <img src="https://pizzaonline.dominos.co.in/static/assets/icons/great_food.svg" alt=''/>
                           <div className="hd-img__sbtxt__img-txt">
                              <p>Great</p>
                              <p>Food</p>
                           </div>
                        </div>
                        <div>
                           <img src="https://pizzaonline.dominos.co.in/static/assets/icons/great_offers.svg" alt=''/>
                           <div className="hd-img__sbtxt__img-txt">
                              <p>Great</p>
                              <p>Offers</p>
                           </div>
                        </div>
                        <div>
                           <img src="https://pizzaonline.dominos.co.in/static/assets/icons/easy_reorder.svg" alt=''/>
                           <div className="hd-img__sbtxt__img-txt">
                              <p>Easy</p>
                              <p>Reordering</p>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div className="injectStyles-sc-1jy9bcf-0 lkFGPr">
                     <div className="sc-cIShpX szDCd">
                        <div className="injectStyles-sc-1jy9bcf-0 gbrjhS"> Login with your valid mobile number</div>
                        {/* <form>
  <div className="row">
    <div className="col">
      <input type="text" className="form-control" placeholder="First name"/>
    </div>
    <div className="col">
      <input type="text" className="form-control" placeholder="Last name"/>
    </div>
  </div>
</form> */}


                        <form>
                           <div className="lgn__cntr">
                              <div className="sc-iAyFgw kHDvIO">
                              <input type="text" placeholder="+91"  className="" data-label="+91" value=""/>
                              </div>
                              <span className="lgn__cntr_inpt-txt">Mobile Number</span>
                              <div className="sc-iAyFgw dnhEbx" data-label="login-mobileNumber" customtype="">
                              <input name="loginNumber" type="text" maxLength="10" value=""/></div>
                           </div>
                           <div className="sc-iAyFgw fNsQwG">
                           <input type="submit" className="non-empty"  value="SUBMIT" /></div>
                        </form>
                     </div>
                  </div>
                  <div className="injectStyles-sc-1jy9bcf-0 kVjhQZ">
                     <div className="sc-kafWEX eiByeg">
                        <div className="injectStyles-sc-1jy9bcf-0 jGFovF"> Login with social accounts</div>
                        <div className="scl--cntr">
                           <div>
                              <div className="injectStyles-sc-1jy9bcf-0 hEHLeJ">
                                 <button className="btn--blue">
                                    <div className="injectStyles-sc-1jy9bcf-0 ddacmF"></div>
                                    <span>Facebook</span>
                                 </button>
                              </div>
                           </div>
                           <div type="button" className="google" >
                              <div className="injectStyles-sc-1jy9bcf-0 hEHLeJ">
                                 <button className="btn--red">
                                    <div className="injectStyles-sc-1jy9bcf-0 clqeyD"></div>
                                    <span>Google</span>
                                 </button>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div className="lwr-actns"><span>TERMS OF USE</span></div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
        );
        }
export default LoginPage;