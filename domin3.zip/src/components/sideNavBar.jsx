import React, { useState } from "react";
import Button from "react-bootstrap/Button";
import Card from "react-bootstrap/Card";
import Collapse from "react-bootstrap/Collapse";

function SideNavBar() {
  const [open, setOpen] = useState(false);

  return (
    <>
      <Button
        onClick={() => setOpen(!open)}
        aria-controls="example-collapse-text"
        aria-expanded={open}
      >
        <i className="fa-solid fa-bars"></i>
      </Button>
      <div style={{ minHeight: "0px" }}>
        <Collapse in={open} dimension="width">
          <div id="example-collapse-text">
            <Card body style={{ width: "400px", height: "700px" }}>
              hgfg
            </Card>
          </div>
        </Collapse>
      </div>
    </>
  );
}

export default SideNavBar;
