import React from "react";
import "./Navbar.css";
import { Link } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.css";
import SideNavBar from "./sideNavBar";
import RightsideNavContent from "./rightsideNavContent";

const Navbar = () => {
  return (
    <div className="NavBar">
      <nav className="navbar navbar-expand-lg navbar-primary bg-primary">
        {/* <span className="hamburger"></span>
        <span className="hamburger"></span>
        <span className="hamburger"></span> */}
        <Link className="navbar-brand" to=" "></Link>
        {/* <img
          className="brand-logo"
          src="https://upload.wikimedia.org/wikipedia/commons/thumb/3/3e/Domino%27s_pizza_logo.svg/800px-Domino%27s_pizza_logo.svg.png "
          alt="dominos logo"
        /> */}
        <SideNavBar />
        <img
          className="brandlogo"
          src="https://pizzaonline.dominos.co.in/static/assets/logo_white.svg"
          alt="Banner"
        />

        <div className="collapse navbar-collapse" id="navbarTogglerDemo03">
          <ul className="navbar-nav mr-auto mt-2 mt-lg-0">
            <li className="nav-item active">
              <Link className="nav-link" to="#">
                Home <span className="sr-only">(current)</span>
              </Link>
            </li>
            <li className="nav-item">
              <div className="addr-prf-cnt">
                <div className="tp--grp">
                  <div className="sc-gzVnrw iPBlYe">
                    <RightsideNavContent />

                    {/* <div className="sc-bZQynM ddxYoR">
                      <label
                        className=" container"
                        data-label="Order_Type_Deliver"
                      >
                        <span>Delivery</span>
                        <input type="radio" readOnly="" name="deliveryType" />
                        <span className="checkmark">
                          <span className="checked"></span>
                        </span>
                      </label>
                    </div> */}
                  </div>
                </div>
              </div>
            </li>

            <li>
              {/* <div className="sc-bZQynM ddxYoR">
                <label className=" container" data-label="Order_Type_Pickup">
                  <span>Pick Up/Dine-in</span>
                  <input type="radio" readOnly="" name="deliveryType" />
                  <span className="checkmark"></span>
                  <span className="checked"></span>
                  <img
                    className="avatarimg"
                    src="https://pizzaonline.dominos.co.in/static/assets/avatar.svg"
                    alt=""
                  />
                </label>
              </div> */}
            </li>
            {/* <div data-label="my-account" className="prf-grp-txt">
              <div>MY ACCOUNT</div>
              <div className="prf-grp-txt-hd">
                <Link to=""></Link> Login | Signup
              </div>
            </div> */}
          </ul>
          <form className="form-inline my-2 my-lg-0"></form>
        </div>
      </nav>
    </div>
  );
};

export default Navbar;
