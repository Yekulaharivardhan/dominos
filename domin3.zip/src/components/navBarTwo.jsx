import React from "react";
import "./navBarTwo.css";
import LoginPage from "../logincomponents/Login";



const NavBarTwo = () => {
 
  return (
    <div>
    <div className="hdr sc-jDwBTQ cMrqAK">
<div className="tp-hdr">
<div className="logo-grp">
<div className="hamburger">
<span></span>
<span></span>
<span></span>
</div>
<div>
<div className="sc-dnqmqq cffcyk">
<div className="side-nav" style={{width: "32%", transition: "all 1s ease 0s", top: "3.1rem", left: "-50%"}}>
<div className="ovrly-child"></div></div></div></div><div>
<div className="sc-dnqmqq jLtAra">
<div className="side-nav" style={{width: "24%", transition: "all 1s ease 0s", top: "3.1rem", left: "-50%"}}>
<div className="ovrly-child"></div></div></div></div><div>
<div className="sc-dnqmqq kDMxJu">
<div className="side-nav" style={{width: "31%", transition: "all 1s ease 0s", top: "3.1rem", left: "-50%"}}>
<div className="ovrly-child"></div></div></div></div><div><div className="sc-dnqmqq kdpPFO">
<div className="side-nav" style={{width: "30%", transition: "all 1s ease 0s", top: "3.1rem", left: "-50%"}}>
<div className="ovrly-child"></div></div></div></div>
<img className="brand-logo" src="https://pizzaonline.dominos.co.in/static/assets/logo_white.svg" alt="dominos logo"/></div><div>
<div className="sc-dnqmqq gmDyxZ">
<div className="custom-width side-nav" style={{width: "32%", transition: "all 1s ease 0s", top: "3.1rem", left: "-50%"}}>
<div className="ovrly-child"></div></div></div></div>
<div className="addr-prf-cnt">
<div className="tp--grp">
<div className="sc-gzVnrw iPBlYe">
<div className="sc-bZQynM ddxYoR">
<label className=" container" data-label="Order_Type_Deliver">
<input type="radio" readOnly="" name="deliveryType"/>
<span>Delivery</span>

<span className="checkmark"><span className="checked"></span></span></label></div>
<div className="sc-bZQynM ddxYoR">
<label className="non--slctd container" data-label="Order_Type_Pickup">
<input type="radio" readOnly="" name="deliveryType"/>

<span>Pick Up/Dine-in</span>

<span className="checkmark"></span></label></div></div></div>
<div className="slct-lctn"><div className="slct-lctn-cnt">
{/* <img src="https://pizzaonline.dominos.co.in/static/assets/avatar.svg" alt=""/> */}

<div className="slct-lctn-txt slct-lctn-txt-slctd">HYDERABAD</div></div>
<div className="injectStyles-sc-1jy9bcf-0 bdMFpM"></div></div>
<div className="prf-grp">
<img src="https://pizzaonline.dominos.co.in/static/assets/avatar.svg" alt="" data-label="profile"/>
<div data-label="my-account" className="prf-grp-txt"><div>MY ACCOUNT</div>
<div className="prf-grp-txt-hd"> <a href={LoginPage} style = {{textDecoration:"none"}}> Login | Signup</a></div></div><div>
<div className="sc-dnqmqq cZHGYi">
<div className="side-nav" style={{width: "32%", transition: "all 1s ease 0s", top: "3.1rem", left: "-50%"}}>
<div className="ovrly-child"></div></div></div></div></div></div></div>
</div>
     {/* <nav className="navbar-secondary bg">
    
    <ul  className="nav justify-content-end">
    <img
          id="brandLogo"
          src="https://pizzaonline.dominos.co.in/static/assets/logo_white.svg"
          alt="Banner"
        />
  <li className="nav-item">
  <span>
   <a className="nav-link active" href=" " style={{color : "lightgray"}}> Delivery<input type="radio" readOnly="" name="deliveryType" />
      <span className="checkmark"></span>
      </a>
      </span>
       </li>
      <li className="nav-item">
            <a className="nav-link" href=" " style={{color : "lightgray"}}>
              Link
              <input type="radio" readOnly="" name="deliveryType" />
              <span className="checkmark"></span>
            </a>
          </li>
          
          <img
              src="https://pizzaonline.dominos.co.in/static/assets/avatar.svg"
              alt="avatar"
              data-label="profile"
            />


          <li className="nav-item">
            <a className="nav-link disabled" href=" "style={{color : "white"}}>
              MY ACCOUNT
            </a>
            <span className="login-signup">Login | Signup</span>
          </li>
        </ul>
      </nav>
    </div> 







            <div>
    <div className="hdr sc-jDwBTQ cMrqAK">
       <div className="tp-hdr">
          <div className="logo-grp">
             <div className="hamburger"><span></span><span></span><span></span></div>
             <div>
                <div className="sc-dnqmqq cffcyk">
                   <div className="side-nav" style={{width: "32%", transition: "all 1s ease 0s", top: "3.1rem", right: "-50%"}}>
                      <div className="ovrly-child"></div>
                   </div>
                </div>
             </div>
             <div>
                <div className="sc-dnqmqq jLtAra">
                   <div className="side-nav" style={{width: "24%", transition: "all 1s ease 0s", top: "3.1rem", left: "-50%"}}>
                      <div className="ovrly-child"></div>
                   </div>
                </div>
             </div>
             <div>
                <div className="sc-dnqmqq kDMxJu">
                   <div className="side-nav" style={{width: "31%", transition: "all 1s ease 0s", top: "3.1rem", right: "-50%"}}>
                      <div className="ovrly-child"></div>
                   </div>
                </div>
             </div>
             <div>
                <div className="sc-dnqmqq kdpPFO">
                   <div className="side-nav" style={{width: "30%", transition: "all 1s ease 0s", top: "3.1rem", left: "-50%"}}>
                      <div className="ovrly-child"></div>
                   </div>
                </div>
             </div>
             <img className="brand-logo" src="/static/assets/logo_white.svg" alt="dominos logo"/>
          </div>
          <div>
             <div className="sc-dnqmqq gmDyxZ">
                <div className="custom-width side-nav" style={{width: "32%", transition: "all 1s ease 0s", top: "3.1rem", right: "-50%"}}>
                   <div className="ovrly-child"></div>
                </div>
             </div>
          </div>
          <div className="addr-prf-cnt">
             <div className="tp--grp">
                <div className="sc-gzVnrw iPBlYe">
                   <div className="sc-bZQynM ddxYoR">
                   <label className=" container" data-label="Order_Type_Deliver"><span>Delivery</span>
                   <input type="radio" readOnly="" name="deliveryType"/>
                   <span className="checkmark"><span className="checked"></span></span></label></div>
                   <div className="sc-bZQynM ddxYoR">
                   <label className="non--slctd container" data-label="Order_Type_Pickup">
                   <span>Pick Up/Dine-in</span>
                   <input type="radio" readOnly="" name="deliveryType"/>
                   <span className="checkmark"></span>
                   </label>
                   </div>
                </div>
             </div>
             <div className="slct-lctn">
                <div className="slct-lctn-cnt">
                   <img src="/static/assets/icons/location_white.png" alt=''/>
                   <div className="slct-lctn-txt slct-lctn-txt-slctd">HYDERABAD</div>
                </div>
                <div className="injectStyles-sc-1jy9bcf-0 bdMFpM"></div>
             </div>
             <div className="prf-grp">
                <img src="/static/assets/avatar.svg" alt="avatar" data-label="profile"/>
                <div data-label="my-account" className="prf-grp-txt">
                   <div>MY ACCOUNT</div>
                   <div className="prf-grp-txt-hd">Login | Signup</div>
                </div>
                <div>
                   <div className="sc-dnqmqq cZHGYi">
                      <div className="side-nav" style={{width: "32%", transition: "all 1s ease 0s", top: "3.1rem", right: "-50%"}}>
                         <div className="ovrly-child"></div>
                      </div>
                   </div>
                </div>
                </div>
                </div>

          </div>
       </div> */}
     </div>
  );
};

export default NavBarTwo;
