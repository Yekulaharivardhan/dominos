import React from "react";
// import { NavLink } from "react-router-dom";
import "./secondNavBar.css";


const SecondNavBar = () => {
  return (

    <div className="sc-htpNat esboMF" style={{marginTop: "20px", paddingLeft: "5rem", paddingRight: "5rem", boxShadow: "rgb(210, 221, 233) 5px 5px 5px", transition: "all 1s ease-in-out 0s"}}>
    <div className="mn-hdr hide" data-label="Everyday Value"><span>EVERYDAY VALUE</span>
      
        </div>

    <div className="mn-hdr hide" data-label="Bestsellers"><span>BESTSELLERS</span></div>  
    <div className="mn-hdr hide" data-label="New Launches"><span>NEW LAUNCHES</span></div>
    <div className="mn-hdr hide" data-label="Paratha Pizza"><span>PARATHA PIZZA</span></div>
    <div className="mn-hdr hide" data-label="Veg Pizza"><span>VEG PIZZA</span></div>
    <div className="mn-hdr hide" data-label="Beverages"><span>BEVERAGES</span></div>
    <div className="mn-hdr hide" data-label="Non-Veg Pizza"><span>NON-VEG PIZZA</span></div>
    <div className="mn-hdr hide" data-label="Chicken Lovers Pizza"><span>CHICKEN LOVERS PIZZA</span></div>
    <div className="mn-hdr hide" data-label="Speciality Chicken"><span>SPECIALITY CHICKEN</span></div>
    <div className="mn-hdr hide" data-label="Sides"><span>SIDES</span></div>
    <div className="mn-hdr hide" data-label="Pizza Mania"><span>PIZZA MANIA</span></div>
    <div className="mn-hdr hide" data-label="Meal for 1"><span>MEAL FOR 1</span></div>
    <div className="mn-hdr hide" data-label="Meal for 2"><span>MEAL FOR 2</span></div>
    <div className="mn-hdr hide" data-label="Meal for 4"><span>MEAL FOR 4</span></div>
    <div className="mn-hdr hide" data-label="Party Combos"><span>PARTY COMBOS</span></div>
    <div className="mn-hdr hide" data-label="Dessert">
    <span>DESSERT</span></div></div>


    // style="margin-top: -3em; padding-left: 5rem; padding-right: 5rem; box-shadow: rgb(210, 221, 233) 5px 5px 5px; transition: all 1s ease-in-out 0s;"
   
   
   
    // <React.Fragment>
    //   <div className="second-Navbar-Content" style={{ paddingLeft: "5rem", paddingRight: "5rem", boxShadow: "rgb(210, 221, 233) 5px 5px 5px", transition: "all 1s ease-in-out 0s"}}>
    //     <nav className="navbar navbar-expand-lg navbar-light bg-light">
    //       <li className="nav-item active">
    //         <NavLink className="nav-link" to="#">
    //           EVERYDAY VALUE <span className="sr-only">(current)</span>
    //         </NavLink>
    //       </li>
    //       <button
    //         className="navbar-toggler"
    //         type="button"
    //         data-toggle="collapse"
    //         data-target="#navbarNav"
    //         aria-controls="navbarNav"
    //         aria-expanded="false"
    //         aria-label="Toggle navigation"
    //       >
    //         <span className="navbar-toggler-icon"></span>
    //       </button>
    //       <div className="collapse navbar-collapse" id="navbarNav">
    //         <ul className="navbar-nav">
    //           <li className="nav-item active">
    //             <NavLink className="nav-link" to="#">
    //               BESTSELLERS <span className="sr-only">(current)</span>
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               NEW LAUNCHES
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               PARATHA PIZZA
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               VEG PIZZA
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               BEVERAGES
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               NON-VEG PIZZA
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               CHICKEN LOVERS PIZZA
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               SPECIALITY CHICKEN
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               SIDES
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               PIZZA MANIA
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               MEAL FOR 1
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               MEAL FOR 2
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               MEAL FOR 3
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               MEAL FOR 4
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               PARTY COMBOS
    //             </NavLink>
    //           </li>
    //           <li className="nav-item">
    //             <NavLink className="nav-link" to="#">
    //               DESSERT
    //             </NavLink>
    //           </li>
    //         </ul>
    //       </div>
    //     </nav>
    //   </div>






      /* <div className="sc-htpNat esboMF">
        <div className="mn-hdr hide" data-label="Everyday Value">
          <span>EVERYDAY VALUE</span>
        </div>
        <div className="mn-hdr active" data-label="Bestsellers">
          <span>BESTSELLERS</span>
        </div>
        <div className="mn-hdr hide" data-label="New Launches">
          <span>NEW LAUNCHES</span>
        </div>
        <div className="mn-hdr hide" data-label="Paratha Pizza">
          <span>PARATHA PIZZA</span>
        </div>
        <div className="mn-hdr hide" data-label="Veg Pizza">
          <span>VEG PIZZA</span>
        </div>
        <div className="mn-hdr hide" data-label="Beverages">
          <span>BEVERAGES</span>
        </div>
        <div className="mn-hdr hide" data-label="Non-Veg Pizza">
          <span>NON-VEG PIZZA</span>
        </div>
        <div className="mn-hdr hide" data-label="Chicken Lovers Pizza">
          <span>CHICKEN LOVERS PIZZA</span>
        </div>
        <div className="mn-hdr hide" data-label="Speciality Chicken">
          <span>SPECIALITY CHICKEN</span>
        </div>
        <div className="mn-hdr hide" data-label="Sides">
          <span>SIDES</span>
        </div>
        <div className="mn-hdr hide" data-label="Pizza Mania">
          <span>PIZZA MANIA</span>
        </div>
        <div className="mn-hdr hide" data-label="Meal for 1">
          <span>MEAL FOR 1</span>
        </div>
        <div className="mn-hdr hide" data-label="Meal for 2">
          <span>MEAL FOR 2</span>
        </div>
        <div className="mn-hdr hide" data-label="Meal for 4">
          <span>MEAL FOR 4</span>
        </div>
        <div className="mn-hdr hide" data-label="Party Combos">
          <span>PARTY COMBOS</span>
        </div>
        <div className="mn-hdr hide" data-label="Dessert">
          <span>DESSERT</span>
        </div>
      </div> }
    </React.Fragment>*/
  );
};

export default SecondNavBar;
