import "./App.css";
import React, { Component } from 'react';

// import SideNavBar from "./components/Navbar";
// import Navbar from "./components/Navbar";
import Cards from "./components/card";
// import NavContent from "./components/NavContent";
import Catbar from "./components/catBar";
import SecondNavBar from "./components/secondNavBar";
// import CartStatusimg from "./components/cartStatus";
import NavBarTwo from './components/navBarTwo'
import LoginPage from "./logincomponents/Login";


class App extends Component {
  
  render() { 
    return (
      <React.Fragment>
   
      {/* <Navbar /> */}
      <NavBarTwo/>
      <SecondNavBar />
      {/* <CartStatusimg /> */}
      {/* <NavContent /> */}
      <Catbar />
     <LoginPage/>
      <Cards />
      
      </React.Fragment>
);
}
}

export default App;
