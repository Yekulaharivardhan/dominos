
import './App.css';
import {CartProvider} from "react-use-cart"
import Homepage from "./Components/homepage";
import NavBar from './Components/Navbar'
import Cart from './Components/cart';

// import NavBarTwo from './Components/navBarTwo';
 import BsModal from './Components/modal';
import NavBarChild from './Components/NavBarChild';
import Catbar from './Components/catbar';
import HomePageTwo from './Components/homepagetwo';
import CatbarTwo from './Components/catbartwo';
import BsModalTwo from './Components/modaltwo';
import PlaceOrderPage from './Components/FullModal';
import { BrowserRouter, Routes } from 'react-router-dom';
import { Route } from 'react-router-dom';






function App() {
  return (
   <div>
   
 

   <BsModal/>
   
   
   <NavBar/>
<NavBarChild/>

<BsModalTwo />

<BrowserRouter>
<CartProvider>
   

<Cart/>
<Routes>
<Route path='./PlaceOrderPage' element={<PlaceOrderPage/>}/>

</Routes>

  




  <div className="container  " style={{marginLeft:"50px", marginTop:"80px",width:"65%", display:"flex"}}>
  
      <div className="row mr-">
      <Catbar/>
      <Homepage/>
      <CatbarTwo/>
      <HomePageTwo/>
      
      </div>
      </div>
   
  
   
</CartProvider>
   </BrowserRouter>
  
   
   </div>
  );
}

export default App;
