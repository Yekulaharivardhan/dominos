import React, { Component, } from 'react';

import './modal.css'






class FormField extends Component {
        

  
    state   = {
        account: {mobilenumber:''},
        disabled: true
     };
     

    //   CustomeStyle ={appearance: "none",
    //  cursor: "pointer",
    //  color: "rgb(255, 255, 255)",
    //  border: "1px solid rgb(255, 255, 255)",
    //  padding: "0.8rem 1.563rem 0.563rem",
    //  fontWeight: "600",
    //  fontSize: "0.9rem",
    //  borderRadius: "3px",
    //  width: "30%",
    //  backgroundColor:" rgb(101, 171, 11)"}
     


    valiDation = e => {
      console.log(e)
      e.preventDefault();
      if(e.target[1].value >= 10  && e.target[1].value.match(/[0-9]/)){
          console.log(e.target[1].value);
         
         alert("Login Success")
          }
          else {
              alert("failed to login")
              }
       
            }
     

        handlebutton =(e) =>{
console.log(e)
            if(e.target.value.length >=10 && e.target.value.match(/[0-9]/)){

                this.setState({ disabled: false });
                document.getElementById("submitbutton").style.backgroundColor="rgb(101, 171, 11)"
                
            }
            else{
             
                document.getElementById("submitbutton").style.backgroundColor="gray"
                document.getElementById("submitbutton").style.border="none"
                this.setState({ disabled: true });
            }
        }
      

         


      render() {
        
        return (
          
<div>


          <form onSubmit={this.valiDation} >
            <div className="login_controls">
              <div className="sc-iAyFgw login_divclass">
            

                <input
                  type="number"
                  placeholder="+91"
                  className=""
                  data-label="+91"
                />
              </div>
              <span className="login_controls_inpt-txt">Mobile Number</span>
              <div
                className="sc-iAyFgw mobile_number_input"
                data-label="login-mobileNumber"
              >
   
    
                <input  onChange={this.handlebutton} id="mobilenumber"   className="loginNumber"  type="text"  maxLength="10" 
                  style={{outline:"none",}}
                />
                 
    
              </div>
              
             
            </div>
            <div className="sc-iAyFgw submit_butn_class" >
              <input id='submitbutton' type="submit" className="non-empty" value="  SUBMIT " disabled= {this.state.disabled} style={{backgroundColor:"gray", }}/>
           
              
            </div>
            
          </form>
          </div>
        );
      }
    }
    // export default  withRouter(FormField)

    export default  FormField