import React, { Component } from 'react';
import './catbar.css'
class Catbar extends Component {
    state = {  } 
    render() { 
        return (

<div className="ref">
<div className="menu-hr"></div>
<div className="cat-bar">
<div className="menu-catname ">BESTSELLERS</div></div></div>


        );
    }
}
 
export default Catbar;