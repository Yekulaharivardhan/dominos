import React, { useState } from 'react';
import {MDBBtn, MDBModal, MDBModalDialog,MDBModalContent,MDBModalHeader,MDBModalTitle,MDBModalBody,MDBModalFooter, MDBNavbarBrand, MDBContainer, MDBNavbar,} from 'mdb-react-ui-kit';
import './Fullmodal.css'
import Cart from './PaymentPage';




export default function PlaceOrderPage() {
  const [fullscreenXXlModal, setFullscreenXXlModal] = useState(false);

  const toggleShow = () => setFullscreenXXlModal(!fullscreenXXlModal);

  return (
    <>
   <MDBNavbar light bgColor='light'>
        <MDBContainer fluid>
          <MDBNavbarBrand href='#'><a href='https://pizzaonline.dominos.co.in/static/assets/logo_white.svg' style={{backgroundColor:"blue"}}></a></MDBNavbarBrand>
        </MDBContainer>
      </MDBNavbar>

      <br />
       <MDBBtn className='mbd_btn_submit' onClick={toggleShow} style={{opacity:"0.1%"}}> SUBMIT</MDBBtn> 
      <MDBModal tabIndex='-1' show={fullscreenXXlModal} setShow={setFullscreenXXlModal}>
      
        <MDBModalDialog size='fullscreen-xxl-down'>
          <MDBModalContent>
            <MDBModalHeader>
              <MDBModalTitle>SUBMIT</MDBModalTitle>
              <MDBBtn
                type='button'
                className='btn-close'
                color='none'
                onClick={toggleShow}
              ></MDBBtn>
            </MDBModalHeader>
            <MDBModalBody>

              <Cart/>
          
            
            </MDBModalBody>
            <MDBModalFooter style={{backgroundColor:"black"}}>
              <MDBBtn type='button' className='btn btn-Primary' color='secondary' onClick={toggleShow}>
                Close
              </MDBBtn>
            </MDBModalFooter>
          </MDBModalContent>
        </MDBModalDialog>
      </MDBModal>
    </>
  );
}
