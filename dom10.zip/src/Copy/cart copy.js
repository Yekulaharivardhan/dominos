import React from 'react';
// import "./cartStatus.css";
import { useCart } from 'react-use-cart'



const Cart23 = () => {
    const{
        isEmpty,
        totalUniqueItems,
        items,
        totalItems,
        cartTotal,
        updateItemQuantity,
        removeItem,
        emptyCart,
    } = useCart();
    if(isEmpty) return<h1 className='text-center'>you cart is empty</h1>
    return ( 
  

<section className='py-4 container'>
    <div className='row justify-content-left'>
        <div className='col-12'>
            <h5>    Cart ({totalUniqueItems}) Total Items:({totalItems})</h5>
            <div className='table table-light table-hover m-5'>
            
                {items.map((item) => (
                    <ul key={item.id}>{item.quantity}x {item.name}   
                        <div>
                            <img src={item.img} style = {{height: '6rem'}} alt=''/>
                        </div>
                        <div>{item.title}</div>
                        <div>{item.price}</div>
                        <div>Quantity ({item.quantity}) </div>
                        <button className='btn btn-info ms-2'
                        onClick={() => updateItemQuantity(item.id, item.quantity -1)} href=" ">-</button>
                     <button className='btn btn-info ms-2' 
                        onClick={() => updateItemQuantity(item.id, item.quantity +1)}>+</button>
                        <button onClick={() => removeItem(item.id)}>Remove Item</button> 
                    
                    </ul>
                    
                ))}
            
            </div>

            
                        


        </div>
        <div className='"col-auto ms-auto'>
            <h2>Total Price:${cartTotal}</h2>
        </div>
<div className='col-auto'>
    <button className='btn btn-warning m2'
    onClick={() => emptyCart()}
    >Empty Cart</button>
    <button className='btn btn-primary'>Place Order</button>
</div>
    </div>
</section>




     );
}
 
export default Cart23;


