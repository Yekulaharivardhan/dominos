import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import Apptwo from './Apptwo.js';

import "bootstrap/dist/css/bootstrap.css";

const rootwo = ReactDOM.createRoot(document.getElementById('roottwo'));
rootwo.render(
  <React.StrictMode>
    <Apptwo />
  </React.StrictMode>
);
