
import './App.css';

import {CartProvider} from "react-use-cart"
// import NavBarTwo from './Components/navBarTwo';
import BsModal from './../src/Components/modal';
import NavBar from './../src/Components/Navbar';
import NavBarChild from './../src/Components/NavBarChild';
import Cart from './../src/Copy/cart2';
import Catbar from './../src/Components/catbar';
import HomePage from './../src/Copy/homepage copy';
import CatbarTwo from './../src/Components/catbartwo';





function Apptwo() {
  return (
   <div>
   
   <BsModal/>
   <NavBar/>
<NavBarChild/>


   <CartProvider>
   
  {/* <div className='mainpage'> */}
  <div className="container  " style={{marginLeft:"50px", marginTop:"80px",width:"80%"}}>
      <div className="row mr-5">
      
      <Cart/>
      <Catbar/>
   <HomePage/>
   <CatbarTwo/>
   <HomePageTwo/>
   </div></div>
   {/* </div> */}
  {/* <NavBarTwo/> */}
  
   
   
   </CartProvider>
   </div>
  );
}

export default Apptwo;
