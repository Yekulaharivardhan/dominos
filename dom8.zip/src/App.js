
import './App.css';
import Homepage from "./Components/homepage";
import NavBar from './Components/Navbar'
import Cart from './Components/cart';
import {CartProvider} from "react-use-cart"
// import NavBarTwo from './Components/navBarTwo';
 import BsModal from './Components/modal';
import NavBarChild from './Components/NavBarChild';
import Catbar from './Components/catbar';
import HomePageTwo from './Components/homepagetwo';
import CatbarTwo from './Components/catbartwo';
import BsModalTwo from './Components/modaltwo';
import PlaceOrderPage from './Components/FullModal';





function App() {
  return (
   <div>
   
 


   <BsModal/>
   
   <NavBar/>
<NavBarChild/>

<BsModalTwo />



   <CartProvider>
   <PlaceOrderPage/>
  {/* <div className='mainpage'> */}
  <div className="container  " style={{marginLeft:"50px", marginTop:"80px",width:"80%"}}>
      <div className="row mr-5">
     
      <Cart/>
      
      <Catbar/>
     
   <Homepage/>
   <CatbarTwo/>
   <HomePageTwo/>
   </div></div>
   {/* </div> */}
  {/* <NavBarTwo/> */}
  
   </CartProvider>

   
  
   
   </div>
  );
}

export default App;
