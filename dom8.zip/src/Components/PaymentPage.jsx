import React from 'react';
import './PaymentPage.css'
import { useCart } from 'react-use-cart'




const Cart = (props) => {
    const{
      // addItem,
        isEmpty,
        // totalUniqueItems,
        items,
        // totalItems,
        cartTotal,
        updateItemQuantity,
        
        // emptyCart,
    } = useCart();

      if(isEmpty) 
   
    return (  
     
      <div className="row mr-5">
    <div className="menu-right" >
    {/* <img className="flash-banner" src="https://api.dominos.co.in/prod-olo-api/images/flashBanner/Dominos_Howzzat_IPL-2021_Menu.jpg" alt=''/> */}
    <div className="sc-eqIVtm card_">
    <div className="cnt " >
    <div className="sc-jqCOkK empty_cart_div" data-label="empty-scrn" style={{transition: "all 01s ease 0s"}}>
    <img src="https://pizzaonline.dominos.co.in/static/assets/empty_cart.png" className="img" alt='' style={{transition: "all 2s ease 0s", height:"300px"}}/>
    <div className="text__wrapper">
    <span className="text__one">Your Cart is Empty</span>
    <span className="text__two">Please add some items from the menu.</span></div></div></div></div></div>
   
    </div>
    )




    return (  



<div className="sc-kpOJdX frPpmm" style={{display:"-ms-inline-flexbox"}}>

<div className="Container_wrpper"> {items.map((item) => (
  <div className='cartsectiondivdsss' >
  <div className='container_wrapper'  key={item.id} style={{width:"900px"}}>
   <div className='jAcaTr' style={{display:"flex",}} >

  <img  src={item.img} className="img-style" alt='' />
    
  <div class="text_container" style={{display:"flex",}}>
  <div class="card-body" style={{width:"550px"}}>

  <h5 className='card-titletwo' style={{fontSize: "0.9rem"}}>{item.title}</h5>
  <p className='card-text' >{item.desc}</p></div>


  <div>
  <p style={{fontSize:"1.3rem", fontWeight:"bolder",color:"rgb(44, 101, 128",marginBottom:"0.05rem",paddingLeft:"25px" }} >₹{item.price}.00</p>
  <div className="btn-toolbar justify-content-between" role="toolbar" aria-label="Small button groups" style={{height:"7px", paddingBottom:"px"}}>
  <div className="btn-group btn-grou-sm mb-2" role="group" aria-label="First group" style={{height:"25px", marginTop:"5px", }}>
 <button type="button" className="btn btn-outline-secondary"   onClick={() => updateItemQuantity(item.id, item.quantity -1)} ><p style={{marginTop:"-6px"}}>-</p></button>
 <button type="button" className="btn btn-outline-secondary"> <p style={{marginTop:"-4px", fontSize:"0.9em"}}>{item.quantity}</p></button>
  <button type="button" className="btn btn-outline-secondary"  onClick={() => updateItemQuantity(item.id, item.quantity +1)}><p style={{marginTop:"-5px",transition: "all 1s ease 0s"}}>+</p></button>
  </div></div>


  </div>
 </div></div>
                   

   
{/* Button Group */}
  
  <p style={{opacity:"15%", width:"88.5%",boxShadow: "rgb(0 0 0 / 25%) 0px 5px 5px 0px, rgb(0 0 0 / 50%) 0px 9px 0px 0px"}}>----------------------------------------------------------------------------------------------------------------------------------------------------</p>
                        </div>
                        </div>
                )) }
                
                </div>       
  
                <div className='checkout_Plcrdr' >
  <div style={{transition: "all 1s ease 0s", justifyContent:"space-around", display:"flex" }}>Subtotal  
  <p> ₹{cartTotal}.00</p>
  <span> ₹{(cartTotal)/100*10}.00</span>
  </div>
 {/* <button className='btn btn-warning'    onClick={() => emptyCart()}    >Empty Cart</button> */}
<button id='plce_ordr' className='btn btn-primary' style={{transition: "all 1s ease 0s", backgroundColor:"rgb(130, 187, 55)", border:"none", width:'90%',margin:"25px",marginLeft:"10px"}} >PLACE ORDER</button></div>
         

        </div>







     );
}
 
export default Cart;


