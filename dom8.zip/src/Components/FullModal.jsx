import React, { useState } from 'react';
import {MDBBtn, MDBModal, MDBModalDialog,MDBModalContent,MDBModalHeader,MDBModalTitle,MDBModalBody,MDBModalFooter,} from 'mdb-react-ui-kit';
import './Fullmodal.css'
import Cart from './PaymentPage';
import NavBar from './Navbar';



export default function PlaceOrderPage() {
  const [fullscreenXXlModal, setFullscreenXXlModal] = useState(false);

  const toggleShow = () => setFullscreenXXlModal(!fullscreenXXlModal);

  return (
    <>
   
      <MDBBtn onClick={toggleShow}>Full screen below xl</MDBBtn>
      <MDBModal tabIndex='-1' show={fullscreenXXlModal} setShow={setFullscreenXXlModal}>
      <NavBar/>
        <MDBModalDialog size='fullscreen-xxl-down'>
          <MDBModalContent>
            <MDBModalHeader>
              <MDBModalTitle>Full screen below xl</MDBModalTitle>
              <MDBBtn
                type='button'
                className='btn-close'
                color='none'
                onClick={toggleShow}
              ></MDBBtn>
            </MDBModalHeader>
            <MDBModalBody>

              <Cart/>
          
            
            </MDBModalBody>
            <MDBModalFooter>
              <MDBBtn type='button' color='secondary' onClick={toggleShow}>
                Close
              </MDBBtn>
            </MDBModalFooter>
          </MDBModalContent>
        </MDBModalDialog>
      </MDBModal>
    </>
  );
}
