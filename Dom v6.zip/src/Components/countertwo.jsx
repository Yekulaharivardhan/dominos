import Counter from "./counter";





const OneTwo =()=>{
     
   
        return (

Counter.state.cart  =0 ? console.log("one") : console.log("two")

        );
    }

 
export default OneTwo;