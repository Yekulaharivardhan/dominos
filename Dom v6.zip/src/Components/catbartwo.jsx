import React, { Component } from 'react';
import './catbar.css'
class CatbarTwo extends Component {
    state = {  } 
    render() { 
        return (

<div className="ref" style={{marginTop:"60px",}}>
<div className="menu-hr"></div>
<div className="cat-bar">
<div className="menu-catname ">NEW LAUNCHES</div></div></div>


        );
    }
}
 
export default CatbarTwo;