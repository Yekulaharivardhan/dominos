import React, { useState } from 'react';
import {MDBBtn,MDBModal,MDBModalDialog,MDBModalContent,MDBModalHeader,MDBModalTitle, MDBModalBody,MDBModalFooter} from 'mdb-react-ui-kit';
import Cart from './cart';



export default function OrderConfirmation() {
  const [fullscreenXXlModal, setFullscreenXXlModal] = useState(false);

  const toggleShow = () => setFullscreenXXlModal(!fullscreenXXlModal);



  return (
    <>

      <MDBBtn onClick={toggleShow}>Full screen below xxl</MDBBtn>
<MDBModal tabIndex='-1' show={fullscreenXXlModal} setShow={setFullscreenXXlModal}>
 <MDBModalDialog size='fullscreen-xxl-down'>
<MDBModalContent>
 <MDBModalHeader>
 <MDBModalTitle>SUBMIT</MDBModalTitle>
 <MDBBtn type='button' className='btn-close' color='none' onClick={toggleShow}></MDBBtn>
            </MDBModalHeader>
            <MDBModalBody>



<Cart/>

            </MDBModalBody>
            <MDBModalFooter>
            <MDBBtn type='button' color='secondary' onClick={toggleShow}>
                Close
              </MDBBtn>
              
            </MDBModalFooter>
          </MDBModalContent>
        </MDBModalDialog>
      </MDBModal>
   
   
   
   
   
   
   
   
   
    </>
 
 
 
 );
}