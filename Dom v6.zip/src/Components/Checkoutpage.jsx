import React from 'react';
// import './cart.css'
import './cartStatus.css'
// import './card.css'
import { useCart } from 'react-use-cart'
 import BsModalTwo from './modaltwo';





const Cart = (props) => {
    const{
      
      addItem,
        isEmpty,
        // totalUniqueItems,
        items,
        // totalItems,
        cartTotal,
        updateItemQuantity,
        
        // emptyCart,
    } = useCart();

      if(isEmpty) 
   
    return (



        
     <div className="container mr-5 cart"  >
      <div className="row mr-5">
    

    <div className="menu-right" >
    {/* <img className="flash-banner" src="https://api.dominos.co.in/prod-olo-api/images/flashBanner/Dominos_Howzzat_IPL-2021_Menu.jpg" alt=''/> */}
    <div className="sc-eqIVtm card_container">
    <div className="cnt " >
    <div className="sc-jqCOkK empty_cart_div" data-label="empty-scrn" style={{transition: "all 01s ease 0s"}}>
    <img src="https://pizzaonline.dominos.co.in/static/assets/empty_cart.png" className="img" alt='' style={{transition: "all 2s ease 0s"}}/>
    <div className="text__wrapper">
    <span className="text__1">Your Cart is Empty</span>
    <span className="text__2">Please add some items from the menu.</span></div></div></div></div></div>
    
    {/* <button className="btn btn-outline border-success btn-sm" style={{width:"90px"}} onClick={() =>addItem(props.item)} >ADD TO CART</button> */}

    </div></div>
    
    
    )




    return ( 
  


<div className="menu-right" >
<div className="sc-eqIVtm card_container" >

        <div className="cnt " >
        
    

  {items.map((item) => (

  <div className='cartsectiondiv' style={{ paddingTop:"5%", paddingLeft:"5%",fontSize: "1rem",}} >
     <div className='' 
     key={item.id}>
      <div className='crt-cnt-img'  >
  <img  src={item.img} style={{width:"40%", height:"60px", borderRadius:"10px"}} alt='' />
  </div>
  <div className='cart-contnr-descrptn-title' style={{fontSize: "0.9rem"}}>{item.title}</div>
  <div className='crt-cnt-descrptn-desc' style={{ fontSize: "0.7rem",width:"90%"}}>{item.desc}</div>
                        </div>
                     

   
{/* Button Group */}
   <div className="btn-toolbar justify-content-between" role="toolbar" aria-label="Small button groups" style={{height:"27px", paddingBottom:"5px"}}>
  <div className="btn-group btn-grou-sm mb-2" role="group" aria-label="First group" style={{height:"25px", marginTop:"5px"}}>
 <button type="button" className="btn btn-outline-secondary"   onClick={() => updateItemQuantity(item.id, item.quantity -1)} ><span style={{marginTop:"-187px"}}>-</span></button>
 <button type="button" className="btn btn-outline-secondary"> <span style={{marginTop:"-180px", fontSize:"0.9em"}}>{item.quantity}</span></button>
  <button type="button" className="btn btn-outline-secondary"  onClick={() => updateItemQuantity(item.id, item.quantity +1)}><span style={{marginTop:"-185px",transition: "all 1s ease 0s"}}>+</span></button>
  </div>


 <p style={{fontSize:"1.5rem", fontWeight:"bolder",color:"rgb(44, 101, 128", paddingBottom:"15px", paddingRight:"40px"}} >₹{item.price}.00</p></div>
  <p style={{opacity:"25%", marginBottom:"0px"}}>-----------------------------------------</p>
                        </div>
                       
                )) }
                
                </div>       
  
                <div className='checkout_fit' >
  <div style={{transition: "all 1s ease 0s", justifyContent:"space-around", display:"flex" }}>Subtotal  
  <p> ₹{cartTotal}.00</p></div>
 {/* <button className='btn btn-warning'    onClick={() => emptyCart()}    >Empty Cart</button> */}
<button  className='btn btn-primary' style={{transition: "all 1s ease 0s", backgroundColor:"rgb(130, 187, 55)", border:"none", width:'90%',marginBottom:"12px",marginTop:"-12px",marginLeft:"10px"}} ><BsModalTwo /> </button></div>
         

        </div>


        

</div>







        
           
    




     );
}
 
export default Cart;


