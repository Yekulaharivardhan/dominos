
import './App.css';
import Homepage from "./Components/homepage";
import NavBar from './Components/Navbar'
import Cart from './Components/cart';
import {CartProvider} from "react-use-cart"
// import NavBarTwo from './Components/navBarTwo';
 import BsModal from './Components/modal';
import NavBarChild from './Components/NavBarChild';
import Catbar from './Components/catbar';
import HomePageTwo from './Components/homepagetwo';
import CatbarTwo from './Components/catbartwo';
import { BrowserRouter, Routes} from 'react-router-dom';
import PlaceOrder from './Components/placeOrderCode';
import { Route } from 'react-router-dom';

import BsModalTwo from './Components/modaltwo';
import FullModal from './Components/FullModal';




function App() {
  return (
   <div>
   
   {/* <FullModal/> */}


   <BsModal/>
   
   <NavBar/>
<NavBarChild/>
<BsModalTwo />
   <CartProvider>
   
  {/* <div className='mainpage'> */}
  <div className="container  " style={{marginLeft:"50px", marginTop:"80px",width:"80%"}}>
      <div className="row mr-5">
      <FullModal/>
      <Cart/>
      <Catbar/>
   <Homepage/>
   <CatbarTwo/>
   <HomePageTwo/>
   </div></div>
   {/* </div> */}
  {/* <NavBarTwo/> */}
  
   </CartProvider>

   <BrowserRouter>
   
   
   <Routes>
   
        <Route  path="/placeOrderCode" element={<PlaceOrder />}>
     
   
          
        </Route>
      </Routes>


</BrowserRouter>
  
   
   </div>
  );
}

export default App;
