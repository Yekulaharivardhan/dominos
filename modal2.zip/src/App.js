// import BsModal from "./components/modal";
// import RightSideContent from "./components/RightSideContent";
// import Pagination from "./Pagination";
// import Carousel from "./carousel";
import PlaceOrder from "./components/placeOrderCode";

function App() {
  return (
    <div className="App">
      {/* <BsModal />
      <RightSideContent /> */}
      {/* <Pagination /> */}
      {/* <Carousel /> */}
      <PlaceOrder />
    </div>
  );
}

export default App;
