import React, { Component } from "react";

class PageOne extends Component {
  state = {};
  render() {
    return <h1>Page One Active</h1>;
  }
}

export default PageOne;
