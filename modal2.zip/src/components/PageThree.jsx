import React, { Component } from "react";

class PageThree extends Component {
  state = {};
  render() {
    return <h1>Page Three Active</h1>;
  }
}

export default PageThree;
