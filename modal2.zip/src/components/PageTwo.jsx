import React, { Component } from "react";

class PageTwo extends Component {
  state = {};
  render() {
    return <h1>Page Two Active</h1>;
  }
}

export default PageTwo;
