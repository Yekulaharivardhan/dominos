import React from 'react';
import './Login.css'

const LoginPage = () => {
    return (   
        <div>
   <div className="SideBarContainer loginSideBar">
      <div className="overlay"></div>
      {/* <div className="esc-btn crss-icn-rght">
         <span>esc</span>
         <div className="injectStyles-src gexXsN"></div> */}

         <div className="esc-btn crss-icn-rght">
         <span>esc</span>
         <div className="injectStyles-sc-1jy9bcf-0 gexXsN">

         </div>

      </div>
      <div className="side-nav" style={{width: "32%", transition: "all 1s ease 0s", top: "3.1rem", right: "0px"}}>
         <div className="ovrly-child">
            <div>
               <div className="main LogoContainer">
                  <img className="background_image" src="https://pizzaonline.dominos.co.in/static/assets/login_pizza_image.png" srcSet="https://pizzaonline.dominos.co.in/static/assets/login_pizza_image.png 1x, https://pizzaonline.dominos.co.in/static/assets/login_pizza_image@2x.png 2x, https://pizzaonline.dominos.co.in/static/assets/login_pizza_image@3x.png 3x" alt=''/>
                  <img className="logo_image" src="https://pizzaonline.dominos.co.in/static/assets/Dominos_logo.svg" alt=''/>
                  <div className="login-image">
                     <div className="login-image__txt">
                     <span>Login</span> to unlock awesome new features</div>
                     <div className="login-image__sbtxt">
                        <div>
                           <img src="https://pizzaonline.dominos.co.in/static/assets/icons/great_food.svg" alt=''/>
                           <div className="login-image_subtext_image-text">
                              <p>Great</p>
                              <p>Food</p>
                           </div>
                        </div>
                        <div>
                           <img src="https://pizzaonline.dominos.co.in/static/assets/icons/great_offers.svg" alt=''/>
                           <div className="login-image_subtext_image-text">
                              <p>Great</p>
                              <p>Offers</p>
                           </div>
                        </div>
                        <div>
                           <img src="https://pizzaonline.dominos.co.in/static/assets/icons/easy_reorder.svg" alt=''/>
                           <div className="login-image_subtext_image-text">
                              <p>Easy</p>
                              <p>Reordering</p>
                           </div>
                        </div>
                     </div>
                  </div>

                  




                  <div className="injectStyles-src lkFGPr">
                     <div className="login_container">
                        <div className="injectStyles-src msg_container"> Login with your valid mobile number</div>
                        
                        
                        


                        <form>
                           <div className="login_controls">
                              <div className="sc-iAyFgw login_divclass">
                              <input type="text" placeholder="+91"  className="" data-label="+91" />
                              </div>
                              <span className="login_controls_inpt-txt">Mobile Number</span>
                              <div className="sc-iAyFgw mobile_number_input" data-label="login-mobileNumber" >
                              <input name="loginNumber" type="text" maxLength="10" /></div>
                           </div>
                           <div className="sc-iAyFgw submit_butn_class">
                           <input type="submit" className="non-empty"  value="SUBMIT" /></div>
                        </form>
                     </div>
                  </div>
                  <div className="injectStyles-src login_Socialbtn_cls">
                     <div className="sc-kafWEX eiByeg">
                        <div className="injectStyles-src jGFovF"> Login with social accounts</div>
                        <div className="scl--cntr">
                           <div>
                              <div className="injectStyles-src login_button_cls">
                                 <button className="btn--blue">
                                    <div className="injectStyles-src ddacmF"></div>
                                    <span>Facebook</span>
                                 </button>
                              </div>
                           </div>
                           <div type="button" className="google" >
                              <div className="injectStyles-src login_button_cls">
                                 <button className="btn--red">
                                    <div className="injectStyles-src clqeyD"></div>
                                    <span><a href="https://accounts.google.com/o/oauth2/auth/oauthchooseaccount?redirect_uri=storagerelay%3A%2F%2Fhttps%2Fpizzaonline.dominos.co.in%3Fid%3Dauth520759&response_type=permission%20id_token&scope=email%20profile%20openid&openid.realm&include_granted_scopes=true&client_id=928101681689-fhhil6jq8g1ftone3bdrt3gfq03bilob.apps.googleusercontent.com&ss_domain=https%3A%2F%2Fpizzaonline.dominos.co.in&prompt&fetch_basic_profile=true&gsiwebsdk=2&flowName=GeneralOAuthFlow" style={{textDecoration:"none", color:"white"}} rel="noopener" > Google </a></span>
                                 </button>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div className="lwr-actns"><span>TERMS OF USE</span></div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>

        );
        }
export default LoginPage;