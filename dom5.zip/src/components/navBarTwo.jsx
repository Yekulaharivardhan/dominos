import React from "react";

import BsModal from "./modal";
import "./navBarTwo.css";

const NavBarTwo = () => {
  return (
    <div>
      <div className="Main- Main_Container_Class">
        <div className="tp-hdr">
          <div className="logo-group">
            <div className="hamburger">
              <span></span>
              <span></span>
              <span></span>
            </div>
            <div>
              <div className="SideBarContainer sbc_cls">
                <div
                  className="side-nav"
                  style={{
                    width: "32%",
                    transition: "all 1s ease 0s",
                    top: "1.1rem",
                    left: "-50%",
                  }}
                >
                  <div className="ovrly-child"></div>
                </div>
              </div>
            </div>
            <div>
              <div className="SideBarContainer jLtAra">
                <div
                  className="side-nav"
                  style={{
                    width: "24%",
                    transition: "all 1s ease 0s",
                    top: "3.1rem",
                    left: "-50%",
                  }}
                >
                  <div className="ovrly-child"></div>
                </div>
              </div>
            </div>
            <div>
              <div className="SideBarContainer kDMxJu">
                <div
                  className="side-nav"
                  style={{
                    width: "31%",
                    transition: "all 1s ease 0s",
                    top: "3.1rem",
                    left: "-50%",
                  }}
                >
                  <div className="ovrly-child"></div>
                </div>
              </div>
            </div>
            <div>
              <div className="SideBarContainer kdpPFO">
                <div
                  className="side-nav"
                  style={{
                    width: "30%",
                    transition: "all 1s ease 0s",
                    top: "3.1rem",
                    left: "-50%",
                  }}
                >
                  <div className="ovrly-child"></div>
                </div>
              </div>
            </div>
            <img
              className="brand-logo"
              src="https://pizzaonline.dominos.co.in/static/assets/logo_white.svg"
              alt="dominos logo"
            />
          </div>
          <div>
            <div className="SideBarContainer gmDyxZ">
              <div
                className="custom-width side-nav"
                style={{
                  width: "32%",
                  transition: "all 1s ease 0s",
                  top: "3.1rem",
                  left: "-50%",
                }}
              >
                <div className="ovrly-child"></div>
              </div>
            </div>
          </div>
          <div className="addr-prf-cnt">
            <div className="tp--grp">
              <div className="sc-gzVnrw nav_Bar_right_Container">
                <div className="sc-bZQynM nav_Bar_right_Container_subcls">
                  <label className=" container" data-label="Order_Type_Deliver">
                    <input type="radio" readOnly="" name="deliveryType" />
                    <span>Delivery</span>

                    <span className="checkmark">
                      <span className="checked"></span>
                    </span>
                  </label>
                </div>
                <div className="sc-bZQynM nav_Bar_right_Container_subcls">
                  <label
                    className="non--slctd container"
                    data-label="Order_Type_Pickup"
                  >
                    <input type="radio" readOnly="" name="deliveryType" />

                    <span>Pick Up/Dine-in</span>

                    <span className="checkmark"></span>
                  </label>
                </div>
              </div>
            </div>
            <div className="slct-lctn">
              <div className="slct-lctn-cnt">
                {/* <img src="https://pizzaonline.dominos.co.in/static/assets/avatar.svg" alt=""/> */}

                <div className="slct-lctn-txt selected_location-txt">
                  <img
                    src="https://pizzaonline.dominos.co.in/static/assets/icons/location_white.png"
                    alt=""
                  />
                  HYDERABAD
                </div>
              </div>
              <div className="injectStyles-src bdMFpM"></div>
            </div>
            <div className="prf-grp">
              <img
                src="https://pizzaonline.dominos.co.in/static/assets/avatar.svg"
                alt=""
                data-label="profile"
              />
              <div data-label="my-account" className="prf-grp-txt">
                <div>MY ACCOUNT</div>
                <div className="prf-grp-txt-hd">
                  <div className="prf-grp-txt-hd"> {<BsModal />}</div>

                  {/* <div style={{ textDecoration: "none" }}> Login | Signup</div> */}
                </div>
              </div>
              <div>
                <div className="SideBarContainer sbc_Divclass">
                  <div
                    className="side-nav"
                    style={{
                      width: "32%",
                      transition: "all 1s ease 0s",
                      top: "3.1rem",
                      left: "-50%",
                    }}
                  >
                    <div className="ovrly-child"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NavBarTwo;
