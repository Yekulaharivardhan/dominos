import React from "react";

const RightsideNavContent = () => {
  return (
    <div>
      <div className="addr-prf-cnt">
        <div className="tp--grp">
          <div className="sc-ifAKCX kAneUI">
            <div className="sc-bxivhb jOzRjN">
              <label className="container" data-label="Order_Type_Deliver">
                <span>Delivery</span>
                <input type="radio" readonly="" name="deliveryType" />
                <span className="checkmark">
                  <span className="checked"></span>
                </span>
              </label>
            </div>
            <div className="sc-bxivhb jOzRjN">
              <label
                className="non--slctd container"
                data-label="Order_Type_Pickup"
              >
                <span id="pick-up">Pick Up/Dine-in</span>
                <input type="radio" readonly="" name="deliveryType" />
                <span className="checkmark"></span>
              </label>
            </div>
          </div>
        </div>
        <div className="slct-lctn">
          <div className="slct-lctn-cnt">
            <img src="/static/assets/icons/location_white.png" alt=""/>
            <div className="slct-lctn-txt selected_location-txt">HYDERABAD</div>
          </div>
          <div className="injectStyles-src bdMFpM"></div>
        </div>
        <div className="prf-grp">
          <img
            src="/static/assets/avatar.svg"
            alt="avatar"
            data-label="profile"
          />
          <div data-label="my-account" className="prf-grp-txt">
            <div>MY ACCOUNT</div>
            <div className="prf-grp-txt-hd">Login | Signup</div>
          </div>
          <div>
            <div className="sc-bZQynM goHSbr">
              <div
                className="side-nav"
                style={{
                  width: "32%",
                  transition: "all 1s ease 0s",
                  top: "3.1rem",
                  right: "-50%",
                }}
              >
                <div className="ovrly-child"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RightsideNavContent;
