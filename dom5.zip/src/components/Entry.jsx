import React from 'react';
import Counter from './counter';



function Entry(props) {
    return ( 
<div>
<div className="cardwrap">
        <div className="card">
          <img className="card-img-top" src={props.cardimgtop} alt=" " />

          <div className="img-wrpr__typ"><div className="injectStyles-sc-1jy9bcf-0 khLfXP"></div></div>

          <div className="img-wrpr__fav" data-label="favorite">


          <div className="injectStyles-sc-1jy9bcf-0 iBNnip"></div>
          <div className="injectStyles-sc-1jy9bcf-0 gmEBsn"></div></div>
<div className="card-body">
<h5 className="card-title">{props.cardtitle}</h5>
<p className="card-text">
{props.cardtext}
</p>
<span className='description'>{props.description}</span>
<Counter/>
</div>
</div></div></div>
  




     );
}

export default Entry;