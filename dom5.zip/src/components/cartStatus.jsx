import React, {Component} from "react";
import "./cartStatus.css";



class CartStatusimg extends Component {
  state = {  } 
  render() { 
    return (

      
<div className="menu-right">
<div className="sc-eqIVtm gDqVYa">
<div className="cnt ">
<div className="sc-hrWEMg ikDfKT" data-label="empty-scrn">
<img src="https://pizzaonline.dominos.co.in/static/assets/empty_cart.png" srcSet="	https://pizzaonline.dominos.co.in/static/assets/empty_cart.png 1x, 	https://pizzaonline.dominos.co.in/static/assets/empty_cart@2x.png 2x, 	https://pizzaonline.dominos.co.in/static/assets/empty_cart@3x.png 3x" className="img" alt=""/>
<div className="text__wrpr"><span className="text__1">Your Cart is Empty</span>
<span className="text__2">Please add some items from the menu. </span></div></div></div></div>




</div>
    );
  }
}

export default CartStatusimg;
