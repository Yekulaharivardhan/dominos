import React from "react";
import "./cartStatus.css";
const CartStatusimg = () => {
  return (
    <div className="sc-eqIVtm gDqVYa">
      <div className="cnt ">
        <div className="sc-jqCOkK hIfplD" data-label="empty-scrn">
          <img
            // src="/static/assets/empty_cart.png"
            srcSet="https://pizzaonline.dominos.co.in/static/assets/empty_cart.png"
            className="img"
            alt=" "
          />
          <div className="text__wrpr">
            <span className="text__1">Your Cart is Empty</span>
            <span className="text__2">
              Please add some items from the menu.
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CartStatusimg;
