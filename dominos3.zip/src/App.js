import "./App.css";
// import SideNavBar from "./components/Navbar";
import Navbar from "./components/Navbar";
import Cards from "./components/card";
import NavContent from "./components/NavContent";
import Catbar from "./components/catBar";
import SecondNavBar from "./components/secondNavBar";
import CartStatusimg from "./components/cartStatus";
function App() {
  return (
    <div className="App">
      <Navbar />
      <SecondNavBar />
      <CartStatusimg />
      <NavContent />
      <Catbar />

      <Cards />
    </div>
  );
}

export default App;
