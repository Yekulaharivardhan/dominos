
import './App.css';
import Navbar from './components/Navbar';
import Cards from './components/card';
import NavContent from './components/NavContent';

function App() {
  return (
    <div className="App">
      <Navbar />
      <Cards/>
      <NavContent/>
    </div>
  );
}

export default App;
