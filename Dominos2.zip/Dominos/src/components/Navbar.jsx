import React from 'react';
import './Navbar.css';



const Navbar = () => {
  return (
    <div>
      <nav className='navbar navbar-expand-md navbar-light fixed-top'>
        <div className='container'>
          <a className='navbar-brand' href='www.domions.com'>
            
          </a>
        </div>
      </nav>
    </div>
  );
};

export default Navbar;
