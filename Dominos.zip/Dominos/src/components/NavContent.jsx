import React from 'react';
const NavContent = () => {
        return (
            <div className="sc-htpNat esboMF" >
            <div className="mn-hdr hide" data-label="Everyday Value"><span>EVERYDAY VALUE</span></div>
            <div className="mn-hdr active" data-label="Bestsellers"><span>BESTSELLERS</span></div>
            <div className="mn-hdr hide" data-label="New Launches"><span>NEW LAUNCHES</span></div>
            <div className="mn-hdr hide" data-label="Paratha Pizza"><span>PARATHA PIZZA</span></div>
            <div className="mn-hdr hide" data-label="Veg Pizza"><span>VEG PIZZA</span></div>
            <div className="mn-hdr hide" data-label="Beverages"><span>BEVERAGES</span></div>
            <div className="mn-hdr hide" data-label="Non-Veg Pizza"><span>NON-VEG PIZZA</span></div>
            <div className="mn-hdr hide" data-label="Chicken Lovers Pizza"><span>CHICKEN LOVERS PIZZA</span></div>
            <div className="mn-hdr hide" data-label="Speciality Chicken"><span>SPECIALITY CHICKEN</span></div>
            <div className="mn-hdr hide" data-label="Sides"><span>SIDES</span></div>
            <div className="mn-hdr hide" data-label="Pizza Mania"><span>PIZZA MANIA</span></div>
            <div className="mn-hdr hide" data-label="Meal for 1"><span>MEAL FOR 1</span></div>
            <div className="mn-hdr hide" data-label="Meal for 2"><span>MEAL FOR 2</span></div>
            <div className="mn-hdr hide" data-label="Meal for 4"><span>MEAL FOR 4</span></div>
            <div className="mn-hdr hide" data-label="Party Combos"><span>PARTY COMBOS</span></div>
            <div className="mn-hdr hide" data-label="Dessert"><span>DESSERT</span></div>
            </div>

        );
    }

 
export default NavContent;