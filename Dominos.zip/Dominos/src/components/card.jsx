import React from 'react';
import './card.css';

const Image = "https://images.dominos.co.in/Paneer.jpg"
const img2 = "https://images.dominos.co.in/4625-CMB1211.jpg"
const img3 = "https://images.dominos.co.in/CMB1250.jpg"
const img4 = "https://images.dominos.co.in/PIZ5158_1.jpg"
const img5 = "https://images.dominos.co.in/PIZ0171.jpg"
const img6 = "https://images.dominos.co.in/PIZ5160_1.jpg"




function Cards(){

    return(
        <div>
<div className="card">
  <img className="card-img-top" src={Image} alt=" "/>
  <div className="card-body">
    <h5 className="card-title">Card title</h5>
    <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="www.dominos.in" className="btn btn-primary" >ADD TO CART</a>
  </div>
</div>

<div className="card">
  <img className="card-img-top" src={img2} alt=" "/>
  <div className="card-body">
    <h5 className="card-title">Meal for 4: Chicken Dominator Combo</h5>
    <p className="card-text">Large Chicken Dominator + 2 Garlic Bread + 2 Pepsi</p>
    <a href="www.dominos.in" className="btn btn-primary" >ADD TO CART</a>
  </div>
</div>


<div className="card">
  <img className="card-img-top" src={img3} alt=" "/>
  <div className="card-body">
    <h5 className="card-title">Card title</h5>
    <p className="card-text">Large Chicken Dominator + 2 Garlic Bread + 2 Pepsi</p>
    <a href="www.dominos.in" className="btn btn-primary" >ADD TO CART</a>
  </div>
</div>


<div className="card">
  <img className="card-img-top" src={img4} alt=" "/>
  <div className="card-body">
    <h5 className="card-title">Card title</h5>
    <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="www.dominos.in" className="btn btn-primary" >ADD TO CART</a>
  </div>
</div>


<div className="card">
  <img className="card-img-top" src={img5} alt=" "/>
  <div className="card-body">
    <h5 className="card-title">Card title</h5>
    <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="www.dominos.in" className="btn btn-primary" >ADD TO CART</a>
  </div>
</div>

<div className="card">
  <img className="card-img-top" src={img6} alt=" "/>
  <div className="card-body">
    <h5 className="card-title">Card title</h5>
    <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="www.dominos.in" className="btn btn-primary" >ADD TO CART</a>
  </div>
</div>

<div className="card">
  <img className="card-img-top" src={img2} alt=" "/>
  <div className="card-body">
    <h5 className="card-title">Card title</h5>
    <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="www.dominos.in" className="btn btn-primary" >ADD TO CART</a>
  </div>
</div>


<div className="card">
  <img className="card-img-top" src={img6} alt=" "/>
  <div className="card-body">
    <h5 className="card-title">Card title</h5>
    <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="www.dominos.in" className="btn btn-primary" >ADD TO CART</a>
  </div>
</div>


<div className="card">
  <img className="card-img-top" src={img5} alt=" "/>
  <div className="card-body">
    <h5 className="card-title">Card title</h5>
    <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="www.dominos.in" className="btn btn-primary" >ADD TO CART</a>
  </div>
</div>

<div className="card">
  <img className="card-img-top" src={img4} alt=" "/>
  <div className="card-body">
    <h5 className="card-title">Card title</h5>
    <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="www.dominos.in" className="btn btn-primary" >ADD TO CART</a>
  </div>
</div>

<div className="card">
  <img className="card-img-top" src={img3} alt=" "/>
  <div className="card-body">
    <h5 className="card-title">Card title</h5>
    <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="www.dominos.in" className="btn btn-primary" >ADD TO CART</a>
  </div>
</div>

<div className="card">
  <img className="card-img-top" src={img2} alt=" "/>
  <div className="card-body">
    <h5 className="card-title">Card title</h5>
    <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="www.dominos.in" className="btn btn-primary" >ADD TO CART</a>
  </div>
</div>

<div className="card">
  <img className="card-img-top" src={Image} alt=" "/>
  <div className="card-body">
    <h5 className="card-title">Card title</h5>
    <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="www.dominos.in" className="btn btn-primary" >ADD TO CART</a>
  </div>
</div>

<div className="card">
  <img className="card-img-top" src={img2} alt=" "/>
  <div className="card-body">
    <h5 className="card-title">Card title</h5>
    <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="www.dominos.in" className="btn btn-primary" >ADD TO CART</a>
  </div>
</div>

<div className="card">
  <img className="card-img-top" src={img4} alt=" "/>
  <div className="card-body">
    <h5 className="card-title">Card title</h5>
    <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="www.dominos.in" className="btn btn-primary" >ADD TO CART</a>
  </div>
</div>

<div className="card">
  <img className="card-img-top" src={img6} alt=" "/>
  <div className="card-body">
    <h5 className="card-title">Card title</h5>
    <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="www.dominos.in" className="btn btn-primary" >ADD TO CART</a>
  </div>
</div>


</div>

    )
}

 
export default Cards;